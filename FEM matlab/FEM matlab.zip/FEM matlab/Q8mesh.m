function [nodes,elems,ndof] = Q8mesh(W,H,nw,nh)
% Square panel mesh generation with Q8 second order elements.
%
% INPUTS:
% W  = width of model
% H  = height of model
% nw = no. of elements in x-direction
% nh = no. of elements in y-direction
%
% OUTPUTS:
% nodes = node table: 1=x-coordinate, 2=y-coordinate, (row no. = node no.)
% elems = element table: 1=node i, 2=node j, ... (row no. = elem no.) 

    % nodes per element
    npe = 8;
 
    % no. of dof's
    ndof = 2*((1 + 2*nh) * (nw + 1) + (1 + nh)*nw);
 
    % no. of nodes
    nn = ndof/2;
    nx = 2*nw+1;
    ny = 2*nh+1;
 
    % no. elements
    ne = nw*nh;
 
    % initialize arrays
    nodes = zeros(nn,2);
    elems = zeros(ne,8);
 
    % grid of nodal coordinates
    x_grid = linspace(0,W,nx);
    y_grid = linspace(0,H,ny);
 
    % setup node table   
    n = 0; % node number
    for i = 1:nx
        if rem(i,2) % i is odd
            for j=1:ny
                n = n+1;
                nodes(n,1) = x_grid(i);
                nodes(n,2) = y_grid(j);
            end
        else
            for j=1:2:ny
                n = n+1;
                nodes(n,1) = x_grid(i);
                nodes(n,2) = y_grid(j);
            end
        end
    end
    
    % setup element table
    e_no = 0;
    for i = 1:ne
        e_no = e_no + 1;
        %element coordinates
        y = ceil(i/nw);
        x = i - (y-1)*nw;
 
        %nodes to corresponding element no.
        n1 = (x-1)*( (2*nh+1) + (nh+1) ) + (y-1)*2 + 1;
        n2 = (x)*( (2*nh+1)+(nh+1) ) + (y-1)*2 + 1;
        n3 = n2 + 2;
        n4 = n1 + 2;
        n5 = (x)*( (2*nh+1)+(nh+1) ) - (nh-y) - 1;
        n6 = n2 + 1;
        n7 = n5 + 1;
        n8 = n1 + 1;
        elems(e_no,1:npe) = [n1 n2 n3 n4 n5 n6 n7 n8];
    end

end
