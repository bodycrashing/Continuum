function [nodes,elems,ndof] = Q9mesh(W,H,nw,nh)
% Square panel mesh generation with 3-noded triangle elements (T3/CST).
%
% INPUTS:
% W  = width of model
% H  = height of model
% nw = no. of elements in x-direction
% nh = no. of elements in y-direction
%
% OUTPUTS:
% nodes = node table: 1=x-coordinate, 2=y-coordinate, (row no. = node no.)
% elems = element table: 1=node i, 2=node j, ... (row no. = elem no.) 

    nh = 2*nh;
    nw = 2*nw;
    
    
    
    % no. of dof's
    ndof = 2*(nw+1)*(nh+1);

    % no. of nodes
    nn = ndof/2;

    % no. elements
    ne = 2*nw*nh;

    % initialize arrays
    nodes = zeros(nn,2);
    elems = zeros(ne/8,9);

    % grid of nodal coordinates
    x_grid = linspace(0,W,nw+1);
    y_grid = linspace(0,H,nh+1);

    % setup node table
    n = 0; % node number
    for i = 1:(nw+1)
        for j=1:(nh+1)
            n = n+1;
            nodes(n,1) = x_grid(i);
            nodes(n,2) = y_grid(j);
        end
    end

    % setup element table
    e = 0;
    for j=1:nh/2
        
        for i = 1:nw/2
            e = e+1;
            q = 2*i-1;
            
            n1 = 2*(nh+1)*j + q -2*(nh+1);
            n2 = (nh+1) + n1;
            n3 = (nh+1) + n2;
            n4 = n1 + 1;
            n5 = n2 + 1;
            n6 = n3 + 1;
            n7 = n4 + 1;
            n8 = n5 + 1;
            n9 = n6 + 1;
            
            elems(e,1:9) = [n1 n2 n3 n6 n9 n8 n7 n4 n5];
%             e = e+1;
%             elems(e,1:9) = [n9 n8 n7 n4 n1 n5];
        end
    end
    
end
