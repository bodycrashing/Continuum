clear all; clc; close all
nc = 2;
no = 2;

[nodes,elems] = Q6mesh_UnitCell(20,8,nc,no);

plot(nodes(:,1),nodes(:,2),'o')


test_x = reshape(nodes(:,1),2*nc+1,2*no+1);
test_y = reshape(nodes(:,2),2*nc+1,2*no+1);


plot(test_x,test_y)
hold on
plot(test_x',test_y')
axis equal
hold off
